<?php

//Masukkan PHPSESID
$PHPSESSID = "a24s0v8hgqs27mopdc710ks6e5";

//Biarkan Saja URL Ini
$url = "http://affi.cryptoplanets.org/bcheden/ajax.php";

?>
