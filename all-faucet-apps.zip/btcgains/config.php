<?php

//Masukkan PHPSESID
$PHPSESSID = "bk692ekr8vp0k8ciub8dtkehs2";


//Biarkan Saja URL Ini
$url = "http://affi.cryptoplanets.org/btcgains/ajax.php";
