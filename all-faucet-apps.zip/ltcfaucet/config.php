<?php

//Masukkan PHPSESID
$PHPSESSID = "ie5h4ien8n67t2j0j3ele826m1";

//Biarkan Saja URL Ini
$url = "http://freebitcoincash.cryptoplanets.org/DJSNChdiej73dosN8S7KcyJltcfaucet/ajax.php";

?>
