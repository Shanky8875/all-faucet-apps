<?php

//Masukkan PHPSESID
$PHPSESSID = "ksu57cs7h6v49qdannpk5adgc6";

//Biarkan Saja URL Ini
$url = "http://affi.cryptoplanets.org/btcroyale/ajax.php";

?>
