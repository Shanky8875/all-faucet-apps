<?php

//Masukkan PHPSESID
$PHPSESSID = "af23il39haojqk50dane4maid5";


//Biarkan Saja URL Ini
$url = "http://affi.cryptoplanets.org/ethcollector/ajax.php";
