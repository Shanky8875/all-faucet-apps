<?php

//Masukkan PHPSESID
$PHPSESSID = "haipi2ej0ip05dg8l7pmoclrr3";


//Biarkan Saja URL Ini
$url = "http://affi.cryptoplanets.org/ethfarmer/ajax.php";
