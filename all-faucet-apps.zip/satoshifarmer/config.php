<?php

//Masukkan PHPSESID
$PHPSESSID = "vde454adkca413lo4j4j5tfno1";

//Biarkan Saja URL Ini
$url = "http://cryptodiamonds.cryptoplanets.org/satoshifarmer/ajax.php";

?>
