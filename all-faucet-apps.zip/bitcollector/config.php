<?php

//Masukkan PHPSESID
$PHPSESSID = "qbnd36rjuiblt34555kbpj3f25";

//Biarkan Saja URL Ini
$url = "http://cryptodiamonds.cryptoplanets.org/bitcollector/ajax.php";

?>
