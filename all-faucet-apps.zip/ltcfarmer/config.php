<?php

//Masukkan PHPSESID
$PHPSESSID = "0dl4l0m61k6ebq8h7vv4ne11u2";

//Biarkan Saja URL Ini
$url = "affi.cryptoplanets.org/ltcfarmer/ajax.php";

?>
