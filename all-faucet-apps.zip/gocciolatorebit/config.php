<?php

//Masukkan PHPSESID
$PHPSESSID = "1q5jcuf3chspnhvli2so1liq72";


//Biarkan Saja URL Ini
$url = "http://affi.cryptoplanets.org/WfHbDz2J3LgFDFhN8S7KcyJneEdcgocciolatorebit/ajax.php";
