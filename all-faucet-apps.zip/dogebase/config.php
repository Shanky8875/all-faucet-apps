<?php

//Masukkan PHPSESID
$PHPSESSID = "ofl9grq04c6errjk8f7ut0gga2";

//Biarkan Saja URL Ini
$url = "http://cryptodiamonds.cryptoplanets.org/DOGEBASE/ajax.php";

?>
